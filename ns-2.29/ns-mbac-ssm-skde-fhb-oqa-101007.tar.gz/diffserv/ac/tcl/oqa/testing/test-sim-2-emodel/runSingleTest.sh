nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 85 





