Kommentare zum Simulations Setup

Verzeichnis evaluating-mts/sts 
- Simulations Verzeichnisse mit den jeweiligen Skripten
Verzeichnis sts
 - simgle time scale setup
Verzeichnis mts
 - multi time scale setup