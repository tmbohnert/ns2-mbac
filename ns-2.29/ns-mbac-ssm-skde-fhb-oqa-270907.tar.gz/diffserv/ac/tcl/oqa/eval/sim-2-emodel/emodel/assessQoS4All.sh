./assessQoS.sh acTrace-0-LossMon-r80.tr > res-r80.txt
./assessQoS.sh acTrace-0-LossMon-r82.tr > res-r82.txt
./assessQoS.sh acTrace-0-LossMon-r84.tr > res-r84.txt
./assessQoS.sh acTrace-0-LossMon-r86.tr > res-r86.txt
./assessQoS.sh acTrace-0-LossMon-r88.tr > res-r88.txt