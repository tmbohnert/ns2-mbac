# nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 80
# mv acTrace-0-LossMon.tr acTrace-0-LossMon-r80.tr
# mv acTrace-0.tr acTrace-0-r80.tr
# 
# nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 82
# mv acTrace-0-LossMon.tr acTrace-0-LossMon-r82.tr
# mv acTrace-0.tr acTrace-0-r82.tr
# 		
# nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 84
# mv acTrace-0-LossMon.tr acTrace-0-LossMon-r84.tr
# mv acTrace-0.tr acTrace-0-r84.tr

nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 85
mv acTrace-0-LossMon.tr acTrace-0-LossMon-r85.tr
mv acTrace-0.tr acTrace-0-r85.tr
# 
# nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 86
# mv acTrace-0-LossMon.tr acTrace-0-LossMon-r86.tr
# mv acTrace-0.tr acTrace-0-r86.tr
# 		
# nsttn oqa-2mb.tcl 3600 0 Voip EXPOO 88
# mv acTrace-0-LossMon.tr acTrace-0-LossMon-r88.tr
# mv acTrace-0.tr acTrace-0-r88.tr


		


