#!/bin/sh

./emodel 0.02 30 2 $1 

#eof

